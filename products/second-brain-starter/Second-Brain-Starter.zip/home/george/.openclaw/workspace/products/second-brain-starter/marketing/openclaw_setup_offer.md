# OpenClaw Setup (Concierge Install)

**Offer:** Hands‑on OpenClaw installation + configuration so your agent works end‑to‑end.  
**Price:** $500 (normally $1,000) — exclusive for Second‑Brain Starter buyers.

## What you get
- **Environment audit** (OS, Node, Python, dependencies)
- **Clean install** of OpenClaw + gateway
- **Workspace setup** (AGENTS/SOUL/IDENTITY/USER/MEMORY + folder structure)
- **Memory & compaction tuning** (safe defaults + pre‑compaction memory flush)
- **Core automations** (startup brief, wrap‑up, cron schedules)
- **Connectivity** (Telegram/webchat/Slack if needed)
- **Security checks** (secrets handling, least‑privilege guidance)
- **Test run** of key workflows
- **Handoff**: walkthrough + maintenance notes

## Timeline
- Typical completion: **2–3 hours** (same day scheduling)

## Requirements (buyer provides)
- Access to the machine (screen share or remote)
- Credentials for services (email, Slack, etc.)
- A private repo if desired for backups

## How to book
Email **contactus@twiniti.ai** with:
- preferred time window
- system details (OS, location)
- which channels/tools you want connected

---
Optional add‑ons:
- OpenClaw + Second‑Brain integration
- Slack → Notion / SignalDesk routing
- Custom skills & workflows

#!/usr/bin/env python3
import argparse, json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path


def read_file(path):
    try:
        return Path(path).read_text(encoding="utf-8")
    except Exception:
        return ""


def latest_file(dirpath, suffix=".md"):
    p = Path(dirpath)
    if not p.exists():
        return None
    files = sorted([f for f in p.glob(f"*{suffix}")], reverse=True)
    return files[0] if files else None


def recent_files(dirpath, limit=5):
    p = Path(dirpath)
    if not p.exists():
        return []
    files = sorted([f for f in p.glob("*.md")], reverse=True)
    return files[:limit]


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            html = """
<!doctype html>
<html>
<head>
  <meta charset='utf-8'/>
  <title>Second‑Brain Dashboard</title>
  <style>
    body { font-family: Arial, sans-serif; background:#0b0f14; color:#eaeaea; padding:20px; }
    h1,h2 { color:#58a6ff; }
    pre { background:#111; padding:12px; border-radius:8px; white-space:pre-wrap; }
    .grid { display:grid; grid-template-columns:1fr; gap:20px; }
  </style>
</head>
<body>
  <h1>Second‑Brain Dashboard</h1>
  <div class="grid">
    <section><h2>Latest Daily Summary</h2><pre id="daily"></pre></section>
    <section><h2>Latest Handoff</h2><pre id="handoff"></pre></section>
    <section><h2>Recent Captures</h2><pre id="captures"></pre></section>
  </div>
<script>
fetch('/data').then(r=>r.json()).then(data=>{
  document.getElementById('daily').textContent = data.daily || 'No summary found.';
  document.getElementById('handoff').textContent = data.handoff || 'No handoff found.';
  document.getElementById('captures').textContent = data.captures || 'No captures found.';
});
</script>
</body>
</html>
"""
            self.wfile.write(html.encode("utf-8"))
            return

        if self.path == "/data":
            repo = Path(self.server.repo)
            daily = latest_file(repo / "summaries" / "daily")
            handoff = latest_file(repo / "summaries" / "handoff")
            captures = recent_files(repo / "daily", limit=5)

            data = {
                "daily": read_file(daily) if daily else "",
                "handoff": read_file(handoff) if handoff else "",
                "captures": "\n\n".join([read_file(f) for f in captures])
            }

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(data).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="Path to second-brain repo")
    ap.add_argument("--port", type=int, default=8788)
    args = ap.parse_args()

    server = HTTPServer(("0.0.0.0", args.port), Handler)
    server.repo = args.repo
    print(f"Dashboard on :{args.port} -> {args.repo}")
    server.serve_forever()
